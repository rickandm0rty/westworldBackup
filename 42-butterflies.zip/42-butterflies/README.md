# 42 Butterflies #

Contained within this zip file you will find all the assets and files for 42 Butterflies.

The icon set is Font Awesome (http://www.fontawesome.org).
The font is Grand Hotel (https://fonts.google.com/specimen/Grand+Hotel).

